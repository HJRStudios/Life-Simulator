// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "MapSync.h"
#include "Engine.h"
